# -*- coding: utf-8 -*-
# import tensorflow as tf
# import os
# import numpy as np
import requests
import my_fake_useragent as ua
import re
import random

# 蓝色背景
def blue_print(*s, end='\n'):
    for item in s:
        print('\033[46m {} \033[0m'.format(item), end='')
    print(end=end)


# 高亮，绿色字体，红色背景
def green_print(*s, end='\n'):
    # print('\033[1m {} \033[0m'.format(s), end=end)
    for item in s:
        print('\033[1;32;41m {} \033[0m'.format(item), end='')
    print(end=end)


class download_data():
    def __init__(self):
        # 初始化常用参数
        # 请求头
        self.user_agent = ua.UserAgent()
        # 正则用于匹配响应内容中的图片url
        self.pattern_url = r'"thumbURL":"(.*?)"'


    # 爬虫：从网上下载数据集
    def get_url_from_internet(self, url):
        for i in range(5):
            try:
                # print(self.user_agent.random())
                res = requests.get(url, headers={'User-Agent': self.user_agent.random()}, timeout=5)
                # print(res.text)
                url_list = re.findall(self.pattern_url, res.text)
                # print(url_list)
                return url_list
            except:
                pass

        # 这里可以将请求失败的url存入数据库，防止数据丢失
        return None

    def write_img(self, url):
        for i in range(3):
            try:
                # 真正下载图片数据的，就这两行代码
                res = requests.get(url, headers={'User-Agent': self.user_agent.random()}, timeout=5)
                img = res.content
                # print(img)

                # 将响应内容写入本地*.jpg文件中
                with open('monkey{}.jpg'.format(random.randint(10 ** 8, 10 ** 9)), 'wb') as f:
                    f.write(img)
                print('monkey{} 下载完成'.format(random.randint(10 ** 8, 10 ** 9)))
                return
            except:
                pass

        # 这里可以将请求失败的url存入数据库，防止数据丢失
        return None

if __name__ == '__main__':
    tt = download_data()
    for page in range(0, 100, 30):
        # 构造url，设置range的右边界越大，下载的图片就越多
        url = 'http://image.baidu.com/search/acjson?tn=resultjson_com&ipn=rj&ct=201326592&is=&fp=result&queryWord=%E6%9F%AF%E5%9F%BA&cl=2&lm=-1&ie=utf-8&oe=utf-8&adpicid=&st=&z=&ic=&hd=&latest=&copyright=&word=%E6%9F%AF%E5%9F%BA&s=&se=&tab=&width=&height=&face=&istype=&qc=&nc=1&fr=&expermode=&force=&pn=90&rn=30&gsm=&1574512323895='.format(page)
        url_list = tt.get_url_from_internet(url)
        if url_list:
            for each_url in url_list:
                tt.write_img(each_url)
